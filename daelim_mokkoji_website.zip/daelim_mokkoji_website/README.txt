대림대학교 제47회 임곡대동제 모꼬지 홈페이지
================================================

파일 구성
- index.html : 홈페이지 전체 코드
- assets/mokkoji-logo.jpg : 모꼬지 로고 이미지
- assets/daelim-42-council.jpg : 제42대 대의원회 이미지
- assets/mokkoji-main-banner.jpg : 메인 배너 이미지

미리보기
1. index.html을 브라우저에서 열어 확인할 수 있습니다.
2. 교내 지도는 제공해주신 외부 이미지 URL을 사용합니다. 인터넷 연결이 필요합니다.

GitHub Pages 게시 방법
1. GitHub에서 저장소 lee-tae-in/yangji_daedongjae 를 엽니다.
2. 기존 index.html을 이 폴더의 index.html로 교체합니다.
3. assets 폴더 전체를 저장소 최상위에 업로드합니다. 폴더 구조는 assets/파일명 형태를 유지합니다.
4. Commit changes를 누릅니다.
5. GitHub Pages가 배포되면 https://lee-tae-in.github.io/yangji_daedongjae/ 에서 확인합니다.

확인할 사항
- 사용자가 제공한 일정에는 일반 운영 시간 13:00–21:00과 프로그램 시간 11:00–21:30이 함께 있어, 홈페이지에는 상세 시간표를 그대로 표시하고 카운트다운은 부스 오픈 시간인 11:00 기준으로 설정했습니다.
- 차량 통제 날짜는 제공받은 정보(10월 27일 18:00~10월 31일 12:00)를 그대로 반영했습니다.
- 공연 출연 순서는 제공되지 않아 이름만 기재했습니다.
- 공식 인스타그램 링크와 지도 URL은 제공된 주소를 사용했습니다.
